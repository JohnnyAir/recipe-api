# Express, Monogodb Api
A simple node express recipe api

## Development server
Run `node server.js` or `npm run serve` if you have nodemon installed globally
